
const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 10000;

app.use(bodyParser.json());

app.post('/purchase', async (req, res) => {
  const userAgent = req.get('User-Agent') || '';
  const ip = req.ip || req.connection.remoteAddress || '';
  const pixelId = '937185518267391';
  const accessToken = 'EAATA4gzUsFcBOzAlZBFgmZB6imzumTZCRchX5DMZCogebywWdD2F0OtWWQm32SEk5ZBsJ8iZCSCKw3fkZBDbjLKuPcLD8EZAzsw8aK5Evhr2MH5EMP6KtRgIJl7hFp8DH7GTehHkD8HSf6GS8ZATPzS2IJ6yCOGcOAlbqH6tqqnetqC4jpKNxCVQWOExeyRG15ODQ5wZDZD';

  // fbp e fbc simulados (poderiam ser extraídos de cookies se estivessem disponíveis)
  const fbp = 'fb.1.' + Date.now() + '.1234567890';
  const fbc = 'fb.1.' + Date.now() + '.1234567890';

  const eventData = {
    event_name: 'Purchase',
    event_time: Math.floor(Date.now() / 1000),
    action_source: 'website',
    event_source_url: 'https://famosasbrasilvip.netlify.app/',
    user_data: {
      client_ip_address: ip,
      client_user_agent: userAgent,
      fbp: fbp,
      fbc: fbc
    },
    custom_data: {
      currency: 'BRL',
      value: 20.00
    }
  };

  try {
    const response = await axios.post(
      `https://graph.facebook.com/v19.0/${pixelId}/events?access_token=${accessToken}`,
      { data: [eventData] }
    );
    res.send(response.data);
  } catch (error) {
    console.error(error.response?.data || error.message);
    res.status(500).send(error.response?.data || error.message);
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
